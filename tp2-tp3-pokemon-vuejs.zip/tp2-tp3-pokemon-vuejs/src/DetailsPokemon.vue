<!-- DetailsPokemon.vue

<template>
  <div v-if="pokemon">
    <h2>{{ pokemon.name }}</h2>

    <div>
      <p>Type(s): {{ pokemon.apiTypes.map(type => type.name).join(', ') }}</p>
      <img :src="pokemon.image" :alt="pokemon.name" />
    </div>

    <router-link to="/">Back to Pokedex</router-link>
  </div>
  <div v-else>
    Loading...
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import axios from 'axios';

// Props
const props = defineProps(["id"]);

const pokemon = ref(null);

const fetchPokemonDetails = async () => {
  try {
    const response = await axios.get(`https://pokebuildapi.fr/api/v1/pokemon/${props.id}`);
    pokemon.value = response.data;
  } catch (error) {
    console.error('Error fetching Pokemon details:', error);
  }
};

onMounted(fetchPokemonDetails);
</script> -->