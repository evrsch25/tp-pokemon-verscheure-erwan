<template>
  <div>
    <Pokedex />
    <Footer />
  </div>
</template>

<script setup>
import Pokedex from './components/Pokedex.vue';
import Footer from './components/Footer.vue';
</script>