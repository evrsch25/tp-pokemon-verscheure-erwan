<!-- Pokedex.vue -->

<template>
  <div>
    <ListeTypesPokemon :pokemons="pokemons" />

    <label for="numberOfPokemons">Choix du Nombre de Pokémons : </label>
    <input
      id="numberOfPokemons"
      type="number"
      v-model="numberOfPokemons"
      @input="fetchPokemons"
    />

    <label for="selectedGeneration">Choix de la Génération : </label>
    <select id="selectedGeneration" v-model="selectedGeneration" @change="fetchPokemonsByGeneration">
      <option v-for="generation in generations" :key="generation" :value="generation">
        Génération {{ generation }}
      </option>
    </select>

    <div>
      <router-link v-for="pokemon in pokemons" :key="pokemon.name" :to="{ name: 'DetailsPokemon', params: { id: pokemon.id } }">
        <Pokemon :pokemon="pokemon" />
      </router-link>
    </div>
  </div>
</template>

<script>
import axios from 'axios';
import Pokemon from './Pokemon.vue';
import ListeTypesPokemon from './ListeTypesPokemon.vue';

export default {
  data() {
    return {
      pokemons: [],
      numberOfPokemons: 20,
      selectedGeneration: 1, // Default to the first generation
      generations: [1, 2, 3, 4, 5, 6, 7, 8], // List of available generations
    };
  },
  mounted() {
    this.fetchPokemons();
  },
  methods: {
    async fetchPokemons() {
      try {
        const response = await axios.get(`https://pokebuildapi.fr/api/v1/pokemon/limit/${this.numberOfPokemons}`);
        this.pokemons = response.data;
      } catch (error) {
        console.error('Error fetching Pokemon data:', error);
      }
    },
    async fetchPokemonsByGeneration() {
      try {
        const response = await axios.get(`https://pokebuildapi.fr/api/v1/pokemon/generation/${this.selectedGeneration}`);
        this.pokemons = response.data;
      } catch (error) {
        console.error('Error fetching Pokemon data by generation:', error);
      }
    },
  },
  components: {
    Pokemon,
    ListeTypesPokemon,
  },
};
</script>