<template>
  <div>
    <h2>{{ pokemon.name }}</h2>
    <!-- Affichez les autres détails du Pokémon à partir de l'API -->
  </div>
</template>

<script>
export default {
  data() {
    return {
      pokemon: null,
    };
  },
  mounted() {
    // Utilisez l'identifiant du Pokémon pour appeler l'API de détails
    const pokemonId = this.$route.params.id;
    this.fetchPokemonDetails(pokemonId);
  },
  methods: {
    async fetchPokemonDetails(id) {
      // Utilisez l'identifiant pour faire une requête à l'API de détails du Pokémon
      // Mettez à jour les données du composant avec les détails reçus
    },
  },
};
</script>

<style scoped>
/* Styles spécifiques au composant, si nécessaire */
</style>
