<!-- Footer.vue -->
<template>
  <footer class="footer">
    <p>{{ yourName }} {{ yourFirstName }} {{ yourTPNumber }}</p>
  </footer>
</template>

<script setup>
const yourName = "Verscheure"; 
const yourFirstName = "Erwan"; 
const yourTPNumber = "TPC"; 
</script>

<style scoped>
.footer {
  background-color: grey;
  text-align: center;
  padding: 10px;
  bottom: 0;
  width: 100%;
}
</style>
