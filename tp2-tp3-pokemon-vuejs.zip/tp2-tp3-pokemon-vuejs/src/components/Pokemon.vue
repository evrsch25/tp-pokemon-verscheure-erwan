<template>
    <div :class="['pokemon-card', getTypeClass(pokemon.apiTypes[0])]">
      <img :src="pokemon.image" :alt="pokemon.name" class="pokemon-image" />
  
      <div class="pokemon-info">
        <h2>{{ pokemon.name }}</h2>
  
        <div v-for="type in pokemon.apiTypes" :key="type.name" class="type">
          <img :src="type.image" :alt="type.name" class="type-image" />
          <span>{{ type.name }}</span>
        </div>
  
        <p>Generation: {{ pokemon.apiGeneration }}</p>
      </div>
    </div>
</template>

<script setup>
import "../components/pokemon.css";

const getTypeClass = (type) => {
  if (type) {
    switch (type.name.toLowerCase()) {
      case 'plante':
        return 'green-background';
      case 'feu':
        return 'red-background';
      case 'eau':
        return 'blue-background';
      case 'insecte':
        return 'brown-background';
      case 'vol':
        return 'skyblue-background';
      case 'poison':
        return 'purple-background';
      case 'normal':
        return 'gray-background';
      case 'electric':
        return 'yellow-background';
      default:
        return '';
    }
  }
  return '';
};

// Props
const props = defineProps(["pokemon"]);
</script>